<footer class="main-footer navbar-warning">
        <strong>Copyright &copy; 2022 <a href="https://www.jmtm.co.id">Jasamarga Tollroad Maintenance</a>.</strong>
            -- #Divisi Operations JMTM.
        <div class="float-right d-none d-sm-inline-block">
            <b>Version</b> 1.0.0
        </div>
    </footer>
  </div>