<div class="row">
    <div class="col-md-12">
        <div class="card card-outline card-info">
            <div class="card-header">
                <label class="card-title">
                    Surat Permohonan Persetujuan Izin Prinsip Ca Ke Operasi
                </label>
            </div>
            <div class="card-body">
                <div class="container">
                    ba addendum
                </div>
            </div>
        </div>
    </div>
</div>