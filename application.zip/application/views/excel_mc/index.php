<?php

if ($inisial_add == '_addendum_1') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 1;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 1;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 1;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 1;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 1;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
} else if ($inisial_add == '_addendum_2') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 2;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 2;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 2;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 2;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 2;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
} else if ($inisial_add == '_addendum_3') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 3;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 3;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 3;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 3;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 3;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_4 -->
    // <!-- = 4; -->
} else if ($inisial_add == '_addendum_4') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 4;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 4;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 4;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 4;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 4;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_5 -->
    // <!-- = 5; -->
} else if ($inisial_add == '_addendum_5') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 5;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 5;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 5;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 5;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 5;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_6 -->
    // <!-- = 6; -->
} else if ($inisial_add == '_addendum_6') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 6;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 6;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 6;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 6;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 6;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_7 -->
    // <!-- = 7; -->
} else if ($inisial_add == '_addendum_7') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 7;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 7;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 7;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 7;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 7;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_8 -->
    // <!-- = 8; -->
} else if ($inisial_add == '_addendum_8') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 8;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 8;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 8;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 8;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 8;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_9 -->
    // <!-- = 9; -->
} else if ($inisial_add == '_addendum_9') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 9;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 9;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 9;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 9;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 9;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_10 -->
    // <!-- = 10; -->
} else if ($inisial_add == '_addendum_10') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 10;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 10;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 10;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 10;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 10;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_11 -->
    // <!-- = 11; -->
} else if ($inisial_add == '_addendum_11') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 11;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 11;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 11;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 11;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 11;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_12 -->
    // <!-- = 12; -->
} else if ($inisial_add == '_addendum_12') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 12;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 12;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 12;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 12;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 12;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_13 -->
    // <!-- = 13; -->
} else if ($inisial_add == '_addendum_13') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 13;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 13;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 13;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 13;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 13;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_14 -->
    // <!-- = 14; -->
} else if ($inisial_add == '_addendum_14') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 14;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 14;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 14;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 14;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 14;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_15 -->
    // <!-- = 15; -->
} else if ($inisial_add == '_addendum_15') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 15;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 15;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 15;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 15;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 15;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_16 -->
    // <!-- = 16; -->
} else if ($inisial_add == '_addendum_16') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 16;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 16;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 16;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 16;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 16;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
    // <!-- _addendum_17 -->
    // <!-- = 17; -->
} else if ($inisial_add == '_addendum_17') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 17;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 17;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 17;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 17;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 17;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_18 -->
    // <!-- = 18; -->
} else if ($inisial_add == '_addendum_18') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 18;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 18;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 18;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 18;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 18;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_19 -->
    // <!-- = 19; -->
} else if ($inisial_add == '_addendum_19') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 19;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 19;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 19;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 19;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 19;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_20 -->
    // <!-- = 20; -->
} else if ($inisial_add == '_addendum_20') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 20;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 20;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 20;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 20;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 20;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_21 -->
    // <!-- = 21; -->
} else if ($inisial_add == '_addendum_21') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 21;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 21;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 21;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 21;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 21;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_22 -->
    // <!-- = 22; -->
} else if ($inisial_add == '_addendum_22') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 22;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 22;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 22;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 22;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 22;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_23 -->
    // <!-- = 23; -->
} else if ($inisial_add == '_addendum_23') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 23;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 23;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 23;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 23;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 23;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }


    // <!-- _addendum_24 -->
    // <!-- = 24; -->
} else if ($inisial_add == '_addendum_24') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 24;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 24;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 24;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 24;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 24;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_25 -->
    // <!-- = 25; -->
} else if ($inisial_add == '_addendum_25') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 25;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 25;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 25;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 25;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 25;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_26 -->
    // <!-- = 26; -->
} else if ($inisial_add == '_addendum_26') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 26;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 26;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 26;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 26;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 26;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }


    // <!-- _addendum_27 -->
    // <!-- = 27; -->
} else if ($inisial_add == '_addendum_27') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 27;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 27;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 27;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 27;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 27;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }


    // <!-- _addendum_28 -->
    // <!-- = 28; -->
} else if ($inisial_add == '_addendum_28') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 28;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 28;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 28;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 28;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 28;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_29 -->
    // <!-- = 29; -->
} else if ($inisial_add == '_addendum_29') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 29;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 29;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 29;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 29;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 29;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }

    // <!-- _addendum_30 -->
    // <!-- = 30; -->
} else if ($inisial_add == '_addendum_30') {
    if ($global_type_level == 'level 1') {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 30;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    } else if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 30;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 30;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 30;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 30;
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    }
} else {
    if ($global_type_level == 'level 2') {
        $data_logic['id_hps_penyedia_kontrak_mc_2'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 'kontrak_awal';
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_3', $data_logic);
    } else if ($global_type_level == 'level 3') {
        $data_logic['id_hps_penyedia_kontrak_mc_3'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 'kontrak_awal';
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_4', $data_logic);
    } else if ($global_type_level == 'level 4') {
        $data_logic['id_hps_penyedia_kontrak_mc_4'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 'kontrak_awal';
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_5', $data_logic);
    } else if ($global_type_level == 'level 5') {
        $data_logic['id_hps_penyedia_kontrak_mc_5'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 'kontrak_awal';
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_6', $data_logic);
    } else {
        $data_logic['id_hps_penyedia_kontrak_mc_1'] = $gelobal_id_get_cell;
        $data_logic['type_add'] = 'kontrak_awal';
        $this->load->view('hps_penyedia_kontrak_mc_logic/nilai_level_1', $data_logic);
    }
}
