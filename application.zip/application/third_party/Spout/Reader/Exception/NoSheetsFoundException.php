<?php

namespace Box\Spout\Reader\Exception;

/**
 * Class NoSheetsFoundException
 */
class NoSheetsFoundException extends ReaderException
{
}
